<script setup>
import DonutChart from '../components/DonutChart.vue'
</script>

<template>
  <main>
    <DonutChart team="" />
    <DonutChart team="Avengers" />
    <DonutChart team="JLA" />
  </main>
</template>
